# MarketBook Project Roadmap

Status date: 2026-09-05

## Phase 1 — Market structure foundation

### Country — implemented

- Create
- Get by ID
- Get list
- Persistence and EF mapping
- API integration

### Exchange — implemented

- Create
- Get by ID
- Get list
- Update
- Deactivate
- Optional Country association
- Persistence and EF mapping
- API integration

### Market — implemented

- Create
- Get by ID
- Get all with pagination
- Update
- Deactivate
- Optional Exchange association
- Persistence and EF mapping
- API integration

### Venue — implemented

- Create
- Get by ID
- Get all with pagination
- Update Name and Type
- Activate
- Deactivate
- Required Market association
- Persistence and EF mapping
- API integration

Current Venue design intentionally keeps `VenueCode` and `MarketId` immutable after creation.

## Phase 2 — Listing prerequisites

Recommended order:

### 1. Currency — implemented, pending manual verification

Reason: Listing requires `CurrencyId` as quote currency.

Implemented slice:

- Create Currency
- GetById
- GetAll with pagination
- Update Code, Name, and DecimalPlaces
- Activate / Deactivate
- EF configuration, repository, migration, and API endpoints

Manual API verification is the remaining step before marking Currency fully verified.

### 2. Instrument

Reason: Listing requires `InstrumentId`.

Before implementation, review the current Instrument Domain model and decide which fields are creation-time immutable and which can be updated.

Target slice:

- Create Instrument
- GetById
- GetAll with pagination
- Update supported attributes
- Activate / Deactivate if supported by Domain
- EF configuration, repository, migration, API tests

### 3. Listing

Listing depends on:

- Instrument
- Venue
- Currency

Before implementation, reconcile and finalize Listing invariants, especially trading-symbol uniqueness scope, tick size, precision, primary-listing behavior, and activation lifecycle.

Target slice:

- Create Listing
- GetById
- GetAll / filter by Venue and Instrument
- Activate / Deactivate
- Primary listing operations
- EF configuration and indexes
- API and integration tests

## Phase 3 — Trading calendar and market structure details

Candidates:

- TradingCalendar
- TradingSession
- MarketPrice / price limits

Trading-calendar weekend behavior must be made configurable before supporting markets whose weekends are not Saturday/Sunday.

## Phase 4 — Market data

- Daily prices
- Intraday/tick snapshots
- Order book
- Trade statistics

Only after Listing identity and lifecycle are stable.

## Phase 5 — User-facing portfolio capabilities

- Watchlist
- Portfolio
- Position
- Trade
- Portfolio events

Reference identity rules must be aligned with the finalized Listing model before these slices are persisted.

## Cross-cutting work

These items should proceed alongside feature development:

- Replace placeholder tests with real unit/integration tests.
- Standardize command/query abstractions (either direct `IRequest` or project `ICommand`/`IQuery`) before broad expansion.
- Standardize bilingual XML documentation style.
- Keep pagination normalized through `PageRequest` and `PagedResult`.
- Keep API errors centralized through `ApiErrorMapper`.
- Add concurrency strategy only when a concrete aggregate requires it; do not introduce broad infrastructure prematurely.

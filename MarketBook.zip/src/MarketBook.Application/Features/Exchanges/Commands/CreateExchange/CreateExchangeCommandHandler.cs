// -----------------------------------------------------------------------------
// Project   : MarketBook (Intelligent Market Book System)
// Platform  : Application
// Namespace : MarketBook.Application.Features.Exchanges.Commands.CreateExchange
//
// Copyright (c) Saeid Asadi. All rights reserved.
// Licensed under the MIT License.
// -----------------------------------------------------------------------------

using MarketBook.Application.Abstractions.Messaging;
using MarketBook.Application.Abstractions.Persistence;
using MarketBook.Domain.Common;
using MarketBook.Domain.Country.Aggregates;
using MarketBook.Domain.Country.ValueObjects;
using MarketBook.Domain.Exchange.Aggregates;
using MarketBook.Domain.Exchange.ValueObjects;

namespace MarketBook.Application.Features.Exchanges.Commands.CreateExchange;

/// <summary>
/// EN: Handles the CreateExchangeCommand.
/// FA: فرمان ایجاد بورس را پردازش می‌کند.
/// </summary>
public sealed class CreateExchangeCommandHandler
    : ICommandHandler<CreateExchangeCommand, Result<ExchangeId>>
{
    private readonly IExchangeRepository _exchangeRepository;
    private readonly ICountryRepository _countryRepository;
    private readonly IApplicationDbContext _dbContext;

    /// <summary>
    /// 
    /// </summary>
    /// <param name="exchangeRepository"></param>
    /// <param name="countryRepository"></param>
    /// <param name="dbContext"></param>
    public CreateExchangeCommandHandler(
        IExchangeRepository exchangeRepository,
        ICountryRepository countryRepository,
        IApplicationDbContext dbContext)
    {
        ArgumentNullException.ThrowIfNull(exchangeRepository);
        ArgumentNullException.ThrowIfNull(countryRepository);
        ArgumentNullException.ThrowIfNull(dbContext);

        _exchangeRepository = exchangeRepository;
        _countryRepository = countryRepository;
        _dbContext = dbContext;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="request"></param>
    /// <param name="cancellationToken"></param>
    /// <returns></returns>
    public async Task<Result<ExchangeId>> Handle(
        CreateExchangeCommand request,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);

        CountryId? countryId = null;

        if (!string.IsNullOrWhiteSpace(request.CountryId))
        {
            if (!CountryId.TryParse(
                    request.CountryId,
                    out CountryId? parsedCountryId) ||
                parsedCountryId is null)
            {
                return Result<ExchangeId>.Fail(
                    new Error(
                        "Exchange.InvalidCountryId",
                        "The specified country identifier is invalid."));
            }

            countryId = parsedCountryId;

            Country? country = await _countryRepository.GetByIdAsync(
                countryId,
                cancellationToken);

            if (country is null)
            {
                return Result<ExchangeId>.Fail(
                    new Error(
                        "Exchange.CountryNotFound",
                        "The specified country was not found."));
            }
        }

        ExchangeCode code;

        try
        {
            code = new ExchangeCode(request.Code);
        }
        catch (ArgumentException)
        {
            return Result<ExchangeId>.Fail(
                new Error(
                    "Exchange.InvalidCode",
                    "The specified exchange code is invalid."));
        }

        if (string.IsNullOrWhiteSpace(request.Name))
        {
            return Result<ExchangeId>.Fail(
                new Error(
                    "Exchange.InvalidName",
                    "Exchange name is required."));
        }

        if (await _exchangeRepository.ExistsAsync(
                code,
                cancellationToken))
        {
            return Result<ExchangeId>.Fail(
                new Error(
                    "Exchange.DuplicateCode",
                    "An exchange with the specified code already exists."));
        }

        Exchange exchange = new(
            ExchangeId.New(),
            code,
            request.Name,
            countryId);

        await _exchangeRepository.AddAsync(
            exchange,
            cancellationToken);

        await _dbContext.SaveChangesAsync(
            cancellationToken);

        return Result<ExchangeId>.Success(exchange.Id);
    }
}

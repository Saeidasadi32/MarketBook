// -----------------------------------------------------------------------------
// Project   : MarketBook (Intelligent Market Book System)
// Platform  : MarketBook Platform
// Layer     : Domain
// Namespace : MarketBook.Domain.Industry.ValueObjects
//
// Copyright (c) Saeid Asadi. All rights reserved.
// Licensed under the MIT License.
// -----------------------------------------------------------------------------

using MarketBook.Domain.Common;

namespace MarketBook.Domain.Industry.ValueObjects;

/// <summary>
/// EN: Represents the name of an industry.
/// FA: نام یک صنعت را نمایش می‌دهد.
/// </summary>
public sealed class IndustryName : ValueObject
{
    /// <summary>
    /// EN: Maximum allowed length.
    /// FA: حداکثر طول مجاز.
    /// </summary>
    public const int MaxLength = 200;

    /// <summary>
    /// EN: Initializes a new instance of the <see cref="IndustryName"/> class.
    /// FA: نمونه جدیدی از کلاس <see cref="IndustryName"/> را ایجاد می‌کند.
    /// </summary>
    /// <param name="value">
    /// EN: Industry name.
    /// FA: نام صنعت.
    /// </param>
    public IndustryName(string value)
    {
        Guard.AgainstNullOrWhiteSpace(value);

        value = value.Trim();

        if (value.Length > MaxLength)
        {
            throw new DomainException(
                new Error(
                    $"{nameof(IndustryName)}.TooLong",
                    $"Industry name cannot exceed {MaxLength} characters."));
        }

        Value = value;
    }

    /// <summary>
    /// EN: Gets the industry name.
    /// FA: نام صنعت را دریافت می‌کند.
    /// </summary>
    public string Value { get; }

    /// <inheritdoc/>
    protected override IEnumerable<object?> GetEqualityComponents()
    {
        yield return Value;
    }

    /// <summary>
    /// EN: Converts the value object to string.
    /// FA: مقدار شیء را به رشته تبدیل می‌کند.
    /// </summary>
    public string ToStringValue()
        => Value;

    /// <summary>
    /// EN: Creates an industry name from string.
    /// FA: نام صنعت را از رشته ایجاد می‌کند.
    /// </summary>
    public static IndustryName FromString(string value)
        => new(value);

    /// <inheritdoc />
    public override string ToString()
        => Value;

    /// <summary>
    /// EN: Implicit conversion to string.
    /// FA: تبدیل ضمنی به رشته.
    /// </summary>
    public static implicit operator string(IndustryName name)
    {
        ArgumentNullException.ThrowIfNull(name);

        return name.Value;
    }

    /// <summary>
    /// EN: Explicit conversion from string.
    /// FA: تبدیل صریح از رشته.
    /// </summary>
    public static explicit operator IndustryName(string value)
        => FromString(value);
}

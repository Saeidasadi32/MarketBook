// -----------------------------------------------------------------------------
// Project   : MarketBook (Intelligent Market Book System)
// Platform  : Application
// Namespace : MarketBook.Application.Behaviors
//
// Copyright (c) Saeid Asadi. All rights reserved.
// Licensed under the MIT License.
// -----------------------------------------------------------------------------

using FluentValidation;
using FluentValidation.Results;
using MarketBook.Application.Exceptions;
using MediatR;

namespace MarketBook.Application.Behaviors;

/// <summary>
/// EN: Validates incoming requests before passing them to the next pipeline step.
/// FA: قبل از ارسال درخواست به مرحله بعد Pipeline، اعتبارسنجی را انجام می‌دهد.
/// </summary>
public sealed class ValidationBehavior<TRequest, TResponse>
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : notnull
{
    private readonly List<IValidator<TRequest>> _validators;

    /// <summary>
    /// EN: Initializes a new instance of the <see cref="ValidationBehavior{TRequest, TResponse}"/> class.
    /// FA: نمونه جدیدی از <see cref="ValidationBehavior{TRequest, TResponse}"/> را ایجاد می‌کند.
    /// </summary>
    /// <param name="validators">Registered validators.</param>
    public ValidationBehavior(IEnumerable<IValidator<TRequest>> validators)
    {
        ArgumentNullException.ThrowIfNull(validators);
        _validators = validators.ToList();
    }

    /// <summary>
    /// EN: Validates the request and invokes the next pipeline behavior when validation succeeds.
    /// FA: درخواست را اعتبارسنجی کرده و در صورت موفقیت مرحله بعدی Pipeline را اجرا می‌کند.
    /// </summary>
    /// <param name="request">The request to validate.</param>
    /// <param name="next">The next pipeline delegate.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>The response produced by the next pipeline step.</returns>
    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        ArgumentNullException.ThrowIfNull(next);

        if (_validators.Count == 0)
        {
            return await next(cancellationToken);
        }

        ValidationContext<TRequest> context = new(request);

        ValidationResult[] results = await Task.WhenAll(
            _validators.Select(
                validator => validator.ValidateAsync(
                    context,
                    cancellationToken)));

        List<ValidationFailure> failures = results
            .SelectMany(result => result.Errors)
            .Where(failure => failure is not null)
            .ToList();

        if (failures.Count > 0)
        {
            throw new ApplicationValidationException(failures);
        }

        return await next(cancellationToken);
    }
}

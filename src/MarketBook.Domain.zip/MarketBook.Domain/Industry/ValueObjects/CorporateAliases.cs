﻿// -----------------------------------------------------------------------------
// Project   : MarketBook (Intelligent Market Book System)
// Platform  : MarketBook Platform
// Layer     : Domain
// Namespace : MarketBook.Domain.Industry.ValueObjects
//
// Copyright (c) Saeid Asadi. All rights reserved.
// Licensed under the MIT License.
// -----------------------------------------------------------------------------

using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace MarketBook.Domain.Industry.ValueObjects;

/// <summary>
/// EN: Represents a collection of aliases (alternative names) for a company.
/// FA: مجموعه‌ای از نام‌های جایگزین برای یک شرکت را نمایش می‌دهد.
/// </summary>
public sealed record CorporateAliases
{
    private readonly HashSet<string> _aliases = [];

    /// <summary>
    /// EN: Initializes a new instance of the <see cref="CorporateAliases"/> class.
    /// FA: نمونه جدیدی از کلاس <see cref="CorporateAliases"/> را ایجاد می‌کند.
    /// </summary>
    public CorporateAliases(IEnumerable<string>? aliases = null)
    {
        if (aliases is not null)
        {
            foreach (var alias in aliases)
            {
                Add(alias);
            }
        }
    }

    /// <summary>
    /// EN: Gets all aliases.
    /// FA: همه نام‌های جایگزین را دریافت می‌کند.
    /// </summary>
    public IReadOnlySet<string> Aliases => _aliases;

    /// <summary>
    /// EN: Gets the primary name (first alias).
    /// FA: نام اصلی (اولین نام جایگزین) را دریافت می‌کند.
    /// </summary>
    public string? Primary => _aliases.FirstOrDefault();

    /// <summary>
    /// EN: Gets the count of aliases.
    /// FA: تعداد نام‌های جایگزین را دریافت می‌کند.
    /// </summary>
    public int Count => _aliases.Count;

    /// <summary>
    /// EN: Gets a value indicating whether there are any aliases.
    /// FA: مشخص می‌کند که آیا نام جایگزینی وجود دارد یا خیر.
    /// </summary>
    public bool HasAliases => _aliases.Count > 0;

    /// <summary>
    /// EN: Adds an alias.
    /// FA: یک نام جایگزین اضافه می‌کند.
    /// </summary>
    public void Add(string alias)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(alias);
        _aliases.Add(alias.Trim());
    }

    /// <summary>
    /// EN: Removes an alias.
    /// FA: یک نام جایگزین را حذف می‌کند.
    /// </summary>
    public bool Remove(string alias)
        => _aliases.Remove(alias);

    /// <summary>
    /// EN: Checks if an alias exists.
    /// FA: بررسی می‌کند که نام جایگزین وجود دارد یا خیر.
    /// </summary>
    public bool Contains(string alias)
        => _aliases.Contains(alias);

    /// <summary>
    /// EN: Merges with another alias collection.
    /// FA: با مجموعه نام‌های جایگزین دیگر ادغام می‌کند.
    /// </summary>
    public CorporateAliases Merge(CorporateAliases other)
    {
        var merged = new List<string>(_aliases);
        merged.AddRange(other._aliases);
        return new CorporateAliases(merged);
    }

    /// <summary>
    /// EN: Creates a new instance with an alias added.
    /// FA: نمونه جدیدی با یک نام جایگزین اضافه‌شده ایجاد می‌کند.
    /// </summary>
    public CorporateAliases WithAlias(string alias)
    {
        var newAliases = new List<string>(_aliases) { alias };
        return new CorporateAliases(newAliases);
    }

    /// <summary>
    /// EN: Creates a new instance with an alias removed.
    /// FA: نمونه جدیدی با یک نام جایگزین حذف‌شده ایجاد می‌کند.
    /// </summary>
    public CorporateAliases WithoutAlias(string alias)
    {
        var newAliases = new List<string>(_aliases);
        newAliases.Remove(alias);
        return new CorporateAliases(newAliases);
    }

    /// <inheritdoc />
    public override string ToString()
        => string.Join(", ", _aliases);

    /// <summary>
    /// EN: Implicit conversion to string array.
    /// FA: تبدیل ضمنی به آرایه رشته‌ها.
    /// </summary>
    public static implicit operator string[](CorporateAliases aliases)
        => aliases._aliases.ToArray();

    /// <summary>
    /// EN: Explicit conversion from string array.
    /// FA: تبدیل صریح از آرایه رشته‌ها.
    /// </summary>
    public static explicit operator CorporateAliases(string[] aliases)
        => new(aliases);

    /// <summary>
    /// EN: Implicit conversion from string.
    /// FA: تبدیل ضمنی از رشته.
    /// </summary>
    public static implicit operator CorporateAliases(string alias)
        => new(new[] { alias });

    /// <summary>
    /// EN: Returns an empty alias collection.
    /// FA: یک مجموعه خالی از نام‌های جایگزین برمی‌گرداند.
    /// </summary>
    public static CorporateAliases Empty => new();
}